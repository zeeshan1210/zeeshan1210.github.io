import { useState } from 'react';
import LoginViaACNumber from './LoginViaACNumber';
import LoginViaUsername from './LoginViaUsername';
import { Switch } from 'antd';

const Login = () => {
  const [loginModel, setLoginModel] = useState(true);
  return (
    <>
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          width: '100vw',
          height: '100vh',
          flexDirection: 'column',
        }}
      >
        <div style={{ marginBottom: '1rem' }}>
          Login Via :
          <Switch
            checked={loginModel}
            onChange={(val) => setLoginModel(val)}
            style={{ marginLeft: '1rem', width: '130px' }}
            checkedChildren='Username'
            unCheckedChildren='Account Number'
            defaultChecked
          />
        </div>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-evenly',
            alignItems: 'center',
          }}
        >
          {loginModel ? <LoginViaUsername /> : <LoginViaACNumber />}
        </div>
      </div>
    </>
  );
};

export default Login;
