import { Button, Card, Form, Input, message, Select } from 'antd';
import { useNavigate } from 'react-router-dom';

const { Option } = Select;

const Deposit = () => {
  const navigate = useNavigate();
  return (
    <Card title='Deposit' style={{ width: '100%', height: '100%' }}>
      <Form
        layout={{
          labelCol: {
            span: 8,
          },

          wrapperCol: {
            span: 16,
          },
        }}
        onFinish={() => {
          message.success('Funds Deposited Successfully', 2);
          navigate('/dashboard');
        }}
        initialValues={{ account: '105489863', currency: 'GBP' }}
      >
        <Form.Item
          name='account'
          label='To Account #'
          rules={[{ required: true }]}
        >
          <Input disabled />
        </Form.Item>
        <div style={{ display: 'flex' }}>
          <Form.Item
            style={{ width: '60%', marginRight: '1.5rem' }}
            name='ammount'
            label='Ammount:'
            rules={[{ required: true }]}
          >
            <Input placeholder='Please enter ammount' type='number' />
          </Form.Item>
          <Form.Item
            name='currency'
            label='Currency'
            rules={[{ required: true }]}
            style={{ width: '36.5%' }}
          >
            <Select style={{ marginLeft: '1rem' }}>
              <Option value='GBP'>GBP</Option>
              <Option value='EUR'>EUR</Option>
            </Select>
            {/* <Input placeholder='Please enter ammount' type='number' /> */}
          </Form.Item>
        </div>
        <Form.Item style={{ float: 'right' }}>
          <Button type='primary' htmlType='submit'>
            Transfer
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default Deposit;
