import { Card, Avatar, Select } from 'antd';

const { Meta } = Card;
const { Option } = Select;

const Main = () => {
  const handleChange = (value) => {
    console.log(`selected ${value}`);
  };
  return (
    <Card title='Accounts' style={{ width: '100%', height: '100%' }}>
      <Meta
        avatar={<Avatar src='https://joeschmoe.io/api/v1/random' />}
        title='Zeeshan Mehar'
        // description='50,000 GBP'
        style={{ marginBottom: '2rem' }}
      />
      <div
        style={{
          fontWeight: 'bold',
          display: 'flex',
          justifyContent: 'space-between',
          width: '30%',
        }}
      >
        First Name: <span style={{ fontWeight: 'normal' }}>Zeeshan</span>
      </div>
      <div
        style={{
          fontWeight: 'bold',
          display: 'flex',
          justifyContent: 'space-between',
          width: '30%',
        }}
      >
        Last Name: <span style={{ fontWeight: 'normal' }}>Zeeshan</span>
      </div>
      <div
        style={{
          fontWeight: 'bold',
          display: 'flex',
          justifyContent: 'space-between',
          width: '30%',
        }}
      >
        Email:{' '}
        <span style={{ fontWeight: 'normal' }}>zeeshanmehar@gmail.com</span>
      </div>
      <div
        style={{
          fontWeight: 'bold',
          display: 'flex',
          justifyContent: 'space-between',
          width: '30%',
        }}
      >
        Phone Number:{' '}
        <span style={{ fontWeight: 'normal' }}>+923211234567</span>
      </div>
      <div
        style={{
          fontWeight: 'bold',
          display: 'flex',
          justifyContent: 'space-between',
          width: '30%',
        }}
      >
        Account Type: <span style={{ fontWeight: 'normal' }}>Current</span>
      </div>
      <div
        style={{
          fontWeight: 'bold',
          display: 'flex',
          justifyContent: 'space-between',
          width: '30%',
        }}
      >
        Current Balance: <span style={{ fontWeight: 'normal' }}>50,000</span>
        <Select
          defaultValue='GBP'
          style={{ width: 120, marginLeft: '1rem' }}
          onChange={handleChange}
        >
          <Option value='GBP'>GBP</Option>
          <Option value='EUR'>EUR</Option>
        </Select>
      </div>
    </Card>
  );
};

export default Main;
